/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/workbench/contrib/debug/debugViewlet.nls.keys",[],{vs_workbench_contrib_debug_debugViewlet:{path:"client/vs/workbench/contrib/debug/debugViewlet.js",keys:["variables","callStack","pausedOnException","breakpoints","noWorkspace","pleaseRestart"]}});