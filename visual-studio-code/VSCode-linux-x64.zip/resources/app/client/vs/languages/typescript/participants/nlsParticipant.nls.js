/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript/participants/nlsParticipant.nls",[],{vs_languages_typescript_participants_nlsParticipant:["String needs localization"]});