/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/typescript/participants/nlsParticipant.nls.keys",[],{vs_languages_typescript_participants_nlsParticipant:{path:"client/vs/languages/typescript/participants/nlsParticipant.js",keys:["missing.localize"]}});