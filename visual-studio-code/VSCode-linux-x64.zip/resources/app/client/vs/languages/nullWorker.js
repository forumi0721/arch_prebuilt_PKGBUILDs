/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
"use strict";var __extends=this.__extends||function(e,r){function s(){this.constructor=e}for(var n in r)r.hasOwnProperty(n)&&(e[n]=r[n]);s.prototype=r.prototype,e.prototype=new s};define("vs/languages/nullWorker",["require","exports","vs/editor/worker/modesWorker"],function(e,r,s){var n=function(e){function r(){e.apply(this,arguments)}return __extends(r,e),r}(s.AbstractWorkerMode);r.NullWorker=n});