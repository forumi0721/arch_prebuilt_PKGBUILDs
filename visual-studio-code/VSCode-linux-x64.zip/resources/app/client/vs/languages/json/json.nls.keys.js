/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/json/json.nls.keys",[],{vs_platform_configuration_configurationRegistry:{path:"client/vs/platform/configuration/configurationRegistry.js",keys:["masterUserConfigDesc","masterWorkspaceConfigDesc","masterDefaultConfigDesc"]},vs_languages_json_json:{path:"client/vs/languages/json/json.js",keys:["object","array","string","number","boolean","undefined"]}});