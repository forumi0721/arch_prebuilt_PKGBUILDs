/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/languages/markdown/markdownWorker.nls.keys",[],{vs_languages_markdown_markdownSnippets:{path:"client/vs/languages/markdown/markdownSnippets.js",keys:["bold.snippet","italic.snippet","quote.snippet","code.snippet","fencedcodeblock.snippet","heading.snippet","unorderedList.snippet","orderedList.snippet","rule.snippet","link.snippet","image.snippet"]}});