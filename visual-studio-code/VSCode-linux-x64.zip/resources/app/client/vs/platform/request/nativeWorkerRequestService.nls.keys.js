/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/platform/request/nativeWorkerRequestService.nls.keys",[],{vs_platform_request_nativeWorkerRequestService:{path:"client/vs/platform/request/nativeWorkerRequestService.js",keys:["localFileNotFound"]}});