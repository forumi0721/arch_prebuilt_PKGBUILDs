/*---------------------------------------------------------
 * Copyright (C) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
'use strict';
define(["require", "exports"], function (require, exports) {
    exports.version = null;
    exports.shortVersion = null;
    exports.siteExtensionVersion = null;
});
